# -*- coding: utf-8 -*-
"""
Created on Tue Jan  3 00:21:36 2023

@author: sarathbabu.karunanit
"""

from flask import Flask, render_template, request
import os
import pandas as pd
import sqlite3
import openai
import re

def encrypt(text,s):
    result = ""
    # transverse the plain text
    for i in range(len(text)):
        char = text[i]
        # Encrypt uppercase characters in plain text

        if (char.isupper()):
            result += chr((ord(char) + s-65) % 26 + 65)
        # Encrypt lowercase characters in plain text
        else:
            result += chr((ord(char) + s - 97) % 26 + 97)
    return result


def extract_names(txt,special_character):
    cols=[i for i,j in enumerate(txt) if j==special_character]
    first=cols[::2]
    last=cols[1::2]
    indexes=[txt[i+1:j] for i,j in zip(first,last)]
    return indexes

def encrypt_names(txt):
    names=extract_names(txt,special_character='!')
    names_enc=[]
    for i in names:
        names_enc.append(encrypt(i,4))
        txt=txt.replace(i,encrypt(i,4))
        txt=txt.replace("!","")
    return txt,names_enc,names


openai.api_key = "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"


app = Flask(__name__)

logo_folder = os.path.join('static', 'logo')

app.config['LOGO'] = logo_folder

def natural_to_sql(prompt):
    response = openai.Completion.create(
      model="text-davinci-003",
      prompt=prompt,
      temperature=0.3,
      max_tokens=60,
      top_p=1.0,
      frequency_penalty=0.0,
      presence_penalty=0.0
    )
    
    result=response["choices"][0]['text']
    result = re.sub(":"," ",result)
    return result

def natural_sql_execute(prompt,names_enc,names):
    conn=sqlite3.connect('employee.db')
    c=conn.cursor()
    result=natural_to_sql(prompt)
    df=pd.DataFrame()
    
    for i,j in zip(names_enc,names):
     result=result.replace(i,j)
    
    if 'SELECT' in result:
        query = conn.execute(result)
        cols = [column[0] for column in query.description]
        df= pd.DataFrame.from_records(data = query.fetchall(), columns = cols)
        df = df.iloc[:100,:]
        
        conn.commit()
        conn.close()
        
        return result,df

    c.execute(result)    
    conn.commit()
    conn.close()
    
    return result,df

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    logo_img = os.path.join(app.config['LOGO'],'lv_logo.png')
    
    if request.method == 'POST':
        
        
        conn=sqlite3.connect('employee.db')
        
        result='SELECT * from airline'
        query = conn.execute(result)
        cols = [column[0] for column in query.description]
        df= pd.DataFrame.from_records(data = query.fetchall(), columns = cols)
        df = df.iloc[:100,:]
        
        conn.commit()
        conn.close()
        
        result = request.form['content']
        result,names_enc,names = encrypt_names(result)
        #result = natural_to_sql(result)
        #result,df = natural_sql_execute(result)
        result,df = natural_sql_execute(result,names_enc,names)
        

        #return render_template('index.html',img3=logo_img,result='Describe employee;',tables=[df.to_html(classes='dataframe')], titles=df.columns.values)
        if 'SELECT' in result:
           return render_template('index.html',img3=logo_img,result=result,tables=[df.to_html(classes='dataframe')], titles=df.columns.values)
        else:
             return render_template('index.html',img3=logo_img,result=result)
        #return render_template('index.html',img3=logo_img,result=result,tables=[df.to_html(classes='dataframe')], titles=df.columns.values)
    return render_template('index.html',img3=logo_img)


if __name__ == '__main__':
    app.run(debug=True)
